package com.glasslauncher.ios27

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.widget.*
import android.text.TextWatcher
import android.text.Editable
import kotlin.math.max

class HomeActivity : Activity() {
    private lateinit var repo: AppRepository
    private lateinit var root: FrameLayout
    private var apps: List<AppRepository.AppInfo> = emptyList()
    private var drawer = false
    private var page = 0
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val widgetHost by lazy { AppWidgetHost(this, 2048) }
    private val widgetManager by lazy { AppWidgetManager.getInstance(this) }
    private val hidden by lazy { prefs.getStringSet("hidden_apps", emptySet())?.toMutableSet() ?: mutableSetOf() }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); repo=AppRepository(this); apps=repo.loadApps(); widgetHost.startListening(); root=FrameLayout(this); showHome() }
    private fun txt(s:String,size:Float,color:Int=Color.WHITE)=TextView(this).apply{text=s;textSize=size;setTextColor(color);gravity=Gravity.CENTER}
    private fun visibleApps()=apps.filterNot{hidden.contains(it.packageName)}
    private fun homePackages():MutableList<String>{ val defaults=visibleApps().map{it.packageName}.take(20); return prefs.getStringSet("home_order",null)?.toMutableList()?.filter{p->visibleApps().any{it.packageName==p}}?.toMutableList() ?: defaults.toMutableList() }
    private fun showHome(){drawer=false;root.removeAllViews();root.background=GlassStyle.background()
        val vertical=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,40,16,16)}
        vertical.addView(txt(java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(java.util.Date()),54f))
        vertical.addView(txt(java.text.SimpleDateFormat("EEEE, d MMMM",java.util.Locale.getDefault()).format(java.util.Date()),16f))
        val ordered=homePackages(); val perPage= prefs.getInt("grid_count",16).coerceIn(8,24); val pages=max(1,(ordered.size+perPage-1)/perPage);page=page.coerceIn(0,pages-1)
        val cols=prefs.getInt("columns",4).coerceIn(3,6); val grid=GridLayout(this).apply{columnCount=cols}
        val section=ordered.drop(page*perPage).take(perPage)
        section.forEach{pkg->apps.firstOrNull{it.packageName==pkg}?.let{grid.addView(tile(it),GridLayout.LayoutParams().apply{width=0;height=142;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})}}
        vertical.addView(grid,LinearLayout.LayoutParams(-1,0,1f))
        val pager=LinearLayout(this).apply{gravity=Gravity.CENTER}
        val prev=Button(this).apply{text="‹";setOnClickListener{page=(page-1+pages)%pages;showHome()}};val dots=txt("${page+1} / $pages",14f);val next=Button(this).apply{text="›";setOnClickListener{page=(page+1)%pages;showHome()}};pager.addView(prev);pager.addView(dots);pager.addView(next);vertical.addView(pager)
        val dock=LinearLayout(this).apply{gravity=Gravity.CENTER;orientation=LinearLayout.HORIZONTAL;background=GlassStyle.surface(48f,prefs.getInt("dock_alpha",65));setPadding(8,6,8,6)}
        val dockPkgs=prefs.getStringSet("dock",null)?.toList() ?: visibleApps().take(4).map{it.packageName}; dockPkgs.take(5).forEach{pkg->apps.firstOrNull{it.packageName==pkg}?.let{dock.addView(tile(it,true),LinearLayout.LayoutParams(66,78))}}
        vertical.addView(dock)
        val actions=LinearLayout(this).apply{gravity=Gravity.CENTER};listOf("Apps" to {showDrawer()},"Glass" to {showControlCenter()},"Widgets" to {addWidget()},"Settings" to {startActivity(Intent(this@HomeActivity,SettingsActivity::class.java))}).forEach{(label,action)->actions.addView(Button(this).apply{text=label;setOnClickListener{action()}},LinearLayout.LayoutParams(0,52,1f))};vertical.addView(actions)
        root.addView(vertical);setContentView(root)
    }
    private fun tile(app:AppRepository.AppInfo,dockMode:Boolean=false):View{val size=prefs.getInt("icon_size",58).coerceIn(40,88);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;padding(4)};box.addView(ImageView(this).apply{setImageDrawable(app.icon);scaleType=ImageView.ScaleType.FIT_CENTER},LinearLayout.LayoutParams(if(dockMode)48 else size,if(dockMode)48 else size));if(!prefs.getBoolean("hide_labels",false)&&!dockMode)box.addView(txt(app.label,11f).apply{maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END})
        box.setOnClickListener{repo.launch(app.packageName)};box.setOnLongClickListener{showAppMenu(app);true};box.setOnTouchListener(object:View.OnTouchListener{var down=0f;override fun onTouch(v:View,e:MotionEvent):Boolean{if(e.action==MotionEvent.ACTION_DOWN)down=e.x;return false}});return box}
    private fun LinearLayout.padding(v:Int){setPadding(v,v,v,v)}
    private fun showAppMenu(app:AppRepository.AppInfo){val options=arrayOf("Add/remove from dock","Hide app","Move to next home page","App info");AlertDialog.Builder(this).setTitle(app.label).setItems(options){_,which->when(which){0->toggleDock(app);1->hideApp(app);2->moveApp(app);3->startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:${app.packageName}")))}}.show()}
    private fun toggleDock(app:AppRepository.AppInfo){val set=prefs.getStringSet("dock",null)?.toMutableSet()?:visibleApps().take(4).map{it.packageName}.toMutableSet();if(set.contains(app.packageName))set.remove(app.packageName)else if(set.size<5)set.add(app.packageName);prefs.edit().putStringSet("dock",set).apply();showHome()}
    private fun hideApp(app:AppRepository.AppInfo){hidden.add(app.packageName);prefs.edit().putStringSet("hidden_apps",hidden).apply();showHome()}
    private fun moveApp(app:AppRepository.AppInfo){page=(page+1)%max(1,(homePackages().size+15)/16);Toast.makeText(this,"Use Home layout settings to customize grid; this app is placed on a later page in this build.",Toast.LENGTH_SHORT).show();showHome()}
    private fun showDrawer(){drawer=true;root.removeAllViews();val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,40,16,16)};panel.addView(txt("App Library",28f));val search=EditText(this).apply{hint="Search apps";setSingleLine();background=GlassStyle.surface(28f,65);setPadding(18,12,18,12);setTextColor(-1);hintTextColor=0xffdddddd.toInt()};panel.addView(search,LinearLayout.LayoutParams(-1,56));val scroll=ScrollView(this);val grid=GridLayout(this).apply{columnCount=prefs.getInt("columns",4).coerceIn(3,6)};scroll.addView(grid);panel.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));fun populate(q:String){grid.removeAllViews();visibleApps().filter{it.label.contains(q,true)}.forEach{grid.addView(tile(it),GridLayout.LayoutParams().apply{width=0;height=145;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})}};populate("");search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){populate(s?.toString()?:"")};override fun afterTextChanged(e:Editable?){}});panel.addView(Button(this).apply{text="Home";setOnClickListener{showHome()}});root.addView(panel);setContentView(root)}
    private fun showControlCenter(){root.removeAllViews();val p=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,38,18,18);background=GlassStyle.background()};p.addView(txt("Control Center",28f));val tiles=GridLayout(this).apply{columnCount=2};listOf("Wi-Fi" to android.provider.Settings.ACTION_WIFI_SETTINGS,"Bluetooth" to android.provider.Settings.ACTION_BLUETOOTH_SETTINGS,"Mobile network" to android.provider.Settings.ACTION_DATA_USAGE_SETTINGS,"Airplane mode" to android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS,"Display" to android.provider.Settings.ACTION_DISPLAY_SETTINGS,"Sound" to android.provider.Settings.ACTION_SOUND_SETTINGS).forEach{(name,action)->tiles.addView(Button(this).apply{text=name;setOnClickListener{try{startActivity(Intent(action))}catch(_:Exception){}}},GridLayout.LayoutParams().apply{width=0;height=90;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})};p.addView(tiles);p.addView(txt("Brightness",16f));val brightness=SeekBar(this).apply{max=255;progress=try{android.provider.Settings.System.getInt(contentResolver,android.provider.Settings.System.SCREEN_BRIGHTNESS)}catch(_:Exception){120};setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,v:Int,user:Boolean){if(user)try{android.provider.Settings.System.putInt(contentResolver,android.provider.Settings.System.SCREEN_BRIGHTNESS,v)}catch(_:Exception){startActivity(Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS))};};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })};p.addView(brightness);p.addView(Button(this).apply{text="Flashlight";setOnClickListener{try{startActivity(Intent("android.intent.action.MAIN").setClassName("com.android.settings","com.android.settings.Settings"))}catch(_:Exception){}}});p.addView(Button(this).apply{text="Back to Home";setOnClickListener{showHome()}});root.addView(p);setContentView(root)}
    private fun addWidget(){try{val id=widgetHost.allocateAppWidgetId();val pick=Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);startActivityForResult(pick,300)}catch(e:Exception){Toast.makeText(this,"Widget picker unavailable",Toast.LENGTH_SHORT).show()}}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==300&&resultCode==RESULT_OK&&data!=null){val id=data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);if(id>=0){try{val info=widgetManager.getAppWidgetInfo(id);val view=widgetHost.createView(this,id,info);widgetHost.addView(view);Toast.makeText(this,"Widget added to host (placement UI is basic)",Toast.LENGTH_LONG).show()}catch(_:Exception){}};showHome()}}
    override fun onBackPressed(){if(drawer)showHome()else super.onBackPressed()}
    override fun onDestroy(){try{widgetHost.stopListening()}catch(_:Exception){};super.onDestroy()}
}
