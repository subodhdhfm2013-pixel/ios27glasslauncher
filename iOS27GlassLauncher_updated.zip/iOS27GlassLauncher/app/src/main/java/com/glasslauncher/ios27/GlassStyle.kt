package com.glasslauncher.ios27

import android.graphics.Color
import android.graphics.drawable.GradientDrawable

object GlassStyle {
    fun surface(radius: Float = 32f, alpha: Int = 55): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(Color.argb(alpha, 255, 255, 255))
        setStroke(1, Color.argb(75, 255, 255, 255))
    }
    fun background(): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(18, 24, 54), Color.rgb(75, 68, 135), Color.rgb(26, 97, 125))).apply { cornerRadius = 0f }
}
