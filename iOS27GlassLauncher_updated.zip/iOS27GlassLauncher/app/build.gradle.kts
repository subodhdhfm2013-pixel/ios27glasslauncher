plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.glasslauncher.ios27"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.glasslauncher.ios27"
        minSdk = 24
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
